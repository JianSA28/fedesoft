Rails.application.routes.draw do
    
  resources :images
    
end
